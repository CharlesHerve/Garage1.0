﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using static System.Console;

namespace Garage1._0
{
    class Program
    {
        static void Main(string[] args)
        {
            //var garage = new Garage<Vehicule>();

            //for (int i = 0; i < garage.Capacity; i++)
            //{
            //    WriteLine("Make your choice: 1.Airplane 2.Boat 3.Bus 4.Car 5.Motorbike");
            //    int choice = Int32.Parse(ReadLine());
            //    switch (choice)
            //    {
            //        case 1:
            //            var obj1 = new Airplane();
            //            garage.AddVehicule(obj1, i);
            //            break;
            //        case 2:
            //            var obj2 = new Boat();
            //            garage.AddVehicule(obj2, i);
            //            break;
            //        case 3:
            //            var obj3 = new Bus();
            //            garage.AddVehicule(obj3, i);
            //            break;
            //        case 4:
            //            var obj4 = new Car();
            //            garage.AddVehicule(obj4, i);
            //            break;
            //        case 5:
            //            var obj5 = new Motorbike();
            //            garage.AddVehicule(obj5, i);
            //            break;
            //    }
            //}
            var newSession = new UI();
            newSession.GarageUserInterface();



            //garage.ListAllVehicules();
            //garage.ListAndCountVehiculeTypes();
            //garage.SearchVehiculeViaRegNum();

            //garage.RemoveVehicule();
            //garage.SearchVehiculesWithXParameters();

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using static System.Console;



namespace Garage1._0
{
    //A generic collection of vehicles: Class Garage<T>, where: T should be limited to being Vehicle, ie where T: Vehicle
    // ○ Garage should not inherit from any other class, or implement anything other interface than IEnumerable
    class Garage<T> where T : Vehicule
    {
        //Fields:
        // ○ The collection of vehicles must be handled internally in the class as an array, ie: Vehicle[].
        private T[] vehicules;
        //private int capacity;

        
        //Properties:
        // ○ A capacity required as an input parameter when installing a new Garage:
        public int Capacity { get; set; }
        

        //Constructors:
        public Garage()
        {
            Write("New garage, define its capacity: ");
            int capacity = Int32.Parse(ReadLine());
            Capacity = capacity;
            
            vehicules = new T[Capacity];
            WriteLine($"A garage with a capacity of {Capacity} vehicules is now open.");
            WriteLine();
            WriteLine("**************************************************************************************************************");
        }
        //Populating the array:
        //public void InitializeArray()
        //{
        //    for (int i = 0; i < Capacity; i++)
        //    {
        //        var  objVehicule = new Car("Benzine", "Touring", "C5", "ABC123", "CITROEN", 4, "BLUE", 2000, 4.30f);
               
        //    }
        //}



        // ○ Possibility to add (Park) vehicules: OK
        public void AddVehicule(T vehicule, int position)
        {
            //int indexForNewVehicule = 0;
            //if (vehicules.Length > 0) indexForNewVehicule = vehicules.Length +1;
            //vehicules[indexForNewVehicule] = vehicule;
            vehicules[position] = vehicule;
            WriteLine($"{vehicules[position].RegistrationNumber} is added to the Garage: ");
            WriteLine();
        }

        // Possibility to list all vehicles in the garage:
        public void ListAllVehicules()
        {
            WriteLine();
            WriteLine("List of all the  vehicules in the garage:");
            WriteLine();
            foreach(T vehicule in vehicules)
            {
                vehicule.VehiculeDescription();
                WriteLine();
            }
            WriteLine("**************************************************************************************************************");
        }
        //Possibility to list all types of vehicles in the garage and how many of those in the garage
        public void ListAndCountVehiculeTypes()
        {
            WriteLine();
            WriteLine("Types of vehicles parked in the garage: ");
            int AirplaneAmount = 0;
            int BoatAmount = 0;
            int BusAmount = 0;
            int CarAmount = 0;
            int MotorbikeAmount = 0;
            int UnidentifiedVehiculeAmount = 0;

            foreach (T vehicule in vehicules)
            {
                switch (vehicule.VehiculeType)
                {
                    case "Airplane":
                        AirplaneAmount++;
                        break;
                    case "Boat":
                        BoatAmount++;
                        break;
                    case "Bus":
                        BusAmount++;
                        break;
                    case "Car":
                        CarAmount++;
                        break;
                    case "Motorbike":
                        MotorbikeAmount++;
                        break;
                    default:
                        UnidentifiedVehiculeAmount++;
                        break;
                }//switch
            }//foreach
            WriteLine($"Airplane: {AirplaneAmount} - Boat: {BoatAmount} - Bus: {BusAmount} - Car: {CarAmount} - Motorbike: {MotorbikeAmount}");
            WriteLine("**************************************************************************************************************");
        }//ListAndCountVehiculeTypes()
        public void SearchVehiculeViaRegNum()
        {
            Write("Search a Vehicule with its Registration Number: ");
            string registrationNumber = ReadLine();
            WriteLine();
            for (int i = 0; i < Capacity; i++)
            {
                if (vehicules[i].RegistrationNumber == registrationNumber)
                {
                    vehicules[i].VehiculeDescription();
                }
            }
            WriteLine("**************************************************************************************************************");
        }


         public int ReturnVehiculeIndex(string registrationNumber)
        {
            int index = -1;

            for (int i = 0; i < Capacity; i++)
            {
                if (vehicules[i].RegistrationNumber == registrationNumber)
                {
                    index = i;
                }               
            }
            return index;

        }
        //REMOVE vehicles from the garage:
        public void RemoveVehicule()
        {
            Write("Enter the Registration Number of the vehicule to remove:");
            string registrationNumber = (ReadLine());
            int index = ReturnVehiculeIndex(registrationNumber);
            if (index > -1)
            {
                WriteLine($"The vehicule {vehicules[index].RegistrationNumber} at the place {index} is going to be removed");

                var garageList = new List<T>(vehicules);
                garageList.RemoveAt(index);
                vehicules = garageList.ToArray();

                foreach (T vehicule in vehicules)
                {
                    WriteLine(vehicule.RegistrationNumber);
                }
            }
            else WriteLine("The vehicule you are looking for doesn't exist!");
            
            WriteLine("**************************************************************************************************************");
        }
        public void SearchVehiculesWithXParameters()
        {
            WriteLine();
            WriteLine("Search Vehicules with Multiple Optional Parameters");
            Write("Vehicule Type: ");
            string vehiculeType = ReadLine();
            Write("Brand: ");
            string brand = ReadLine();
            //foreach (T vehicule in vehicules)
            //{

            //}
            if (vehiculeType == "" && brand == "" )
            {
                WriteLine(" Please enter at least one parameter!");
                SearchVehiculesWithXParameters();
            }
            else if (vehiculeType != "" && brand == "")
            {
                foreach (T vehicule in vehicules)
                {
                    if (vehicule.VehiculeType == vehiculeType) WriteLine($"Vehicule number:{vehicule.RegistrationNumber} is a {vehicule.VehiculeType} vehicule type");
                }
            }
            else if (vehiculeType == "" && brand != "")
            {
                foreach (T vehicule in vehicules)
                {
                    if (vehicule.Brand == brand) WriteLine($"Vehicule number:{vehicule.RegistrationNumber} is a {vehicule.Brand} brand. ");
                }
            }
            else
            {
                foreach (T vehicule in vehicules)
                {
                    if (vehicule.VehiculeType == vehiculeType && vehicule.Brand == brand) WriteLine($"Vehicule number:{vehicule.RegistrationNumber} is a {vehicule.Brand} {vehicule.VehiculeType}. ");
                }
            }

            WriteLine("**************************************************************************************************************");
        }

        //public void ReturningVehicules(string vehiculeType = "", string brand = "", string model = "")
        //{

        //}
        
    }//Class garage
}//Namespace
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using static System.Console;

namespace Garage1._0
{   //A UI (User Interface) that allows us to use the functionality of the garage additional Tasks.
    class UI
    {
        public void GarageUserInterface()
        {
            while (true)
            {
                WriteLine("***Garage Management Application****");
                WriteLine("Select your choice:");
                WriteLine("0. Exit - 1. Start a new Garage  ");
                WriteLine("**************************************************************************************************************");
                int choice = Int32.Parse(ReadLine());

                switch (choice)
                {
                    case 0:
                        return;
                    case 1:                        
                        StartNewGarage();
                        break;
                    default:
                        GarageUserInterface();
                        break;
                }                
            }
        }
        public void StartNewGarage()
        {
            var garage = new Garage<Vehicule>();
            for (int i = 0; i < garage.Capacity; i++)
            {
                WriteLine("Make your choice: 1.Airplane 2.Boat 3.Bus 4.Car 5.Motorbike");
                WriteLine("**************************************************************************************************************");
                int choice = Int32.Parse(ReadLine());
                switch (choice)
                {
                    case 1:
                        var obj1 = new Airplane();
                        garage.AddVehicule(obj1, i);
                        break;
                    case 2:
                        var obj2 = new Boat();
                        garage.AddVehicule(obj2, i);
                        break;
                    case 3:
                        var obj3 = new Bus();
                        garage.AddVehicule(obj3, i);
                        break;
                    case 4:
                        var obj4 = new Car();
                        garage.AddVehicule(obj4, i);
                        break;
                    case 5:
                        var obj5 = new Motorbike();
                        garage.AddVehicule(obj5, i);
                        break;
                } 
            }
            while (true)
            {
                WriteLine();
                WriteLine("Garage Menu");
                WriteLine("0. Home - 1. List All Vehicules - 2. List And Count Vehicule Types - 3. Search Vehicule Via Registration Number - 4.Search Vehicule with 2 Parameters - 5. Remove Vehicule -");
                int input = Int32.Parse(ReadLine());
                WriteLine("**************************************************************************************************************");
                switch (input)
                {
                    case 0:
                        return;
                        break;
                    case 1:
                        garage.ListAllVehicules();
                        break;
                    case 2:
                        garage.ListAndCountVehiculeTypes();
                        break;
                    case 3:
                        garage.SearchVehiculeViaRegNum();
                        break;
                    case 4:
                        garage.SearchVehiculesWithXParameters();
                        break;
                    case 5:
                        garage.RemoveVehicule();
                        break;
                }
            }
        }
    }
}
 
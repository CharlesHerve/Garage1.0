﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Garage1._0
{   //A UI (User Interface) that allows us to use the functionality of the garage additional Tasks.
    class UI        
    {
    }
}
